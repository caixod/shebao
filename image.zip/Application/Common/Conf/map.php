<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/4/13
 * Time: 0:11
 */

    //高德地图相关配置
    return array(
      'AMAP_KEY' => 'b6c2c19cf45cd3d2b82541bc857eed7c', //密钥key
      'AMAP_RESTAPI_URL' => 'http://restapi.amap.com/v3/geocode/regeo?output=JSON&radius=1000&extensions=all&',    //地理编码API服务地址
    );