<?php
namespace Home\Behaviors;
class testBehavior extends \Think\Behavior{
    //行为执行入口
    public function run(&$param){        
      //  echo '这是测试的试图解析之前';
    }
}