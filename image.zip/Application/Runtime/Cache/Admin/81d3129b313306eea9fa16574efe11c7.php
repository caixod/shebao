<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>慧智博思管理后台111</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	  <link rel="icon" href="/Public/images/b.ico" type="img/x-ico" />
    <!-- Bootstrap 3.3.4 -->
    <link href="/Public/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- FontAwesome 4.3.0 -->
 	<link href="/Public/bootstrap/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
 	<link href="/Public/layui/css/layui.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 --
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="/Public/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
    	folder instead of downloading all of them to reduce the load. -->
    <link href="/Public/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="/Public/plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- jQuery 2.1.4 -->
    <script src="/Public/plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<script src="/Public/js/global.js"></script>
    <script src="/Public/js/myFormValidate.js"></script>
    <script src="/Public/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="/Public/js/layer/layer-min.js"></script><!-- 弹窗js 参考文档 http://layer.layui.com/-->
    <script src="/Public/js/myAjax.js"></script>
    <script src="/Public/date/WdatePicker.js"></script>
    <script src="/Public/laydate/laydate.js"></script>
    <script type="text/javascript">
    function delfunc(obj){
    	layer.confirm('确认删除？', {
    		  btn: ['确定','取消'] //按钮
    		}, function(){
   				$.ajax({
   					type : 'post',
   					url : $(obj).attr('data-url'),
   					data : {act:'del',del_id:$(obj).attr('data-id')},
   					dataType : 'json',
   					success : function(data){
   						if(data==1){
   							layer.msg('操作成功', {icon: 1});
   							$(obj).parent().parent().remove();
   						}else{
   							layer.msg(data, {icon: 2,time: 2000});
   						}
   						layer.closeAll();
   					}
   				})
    		}, function(index){
    			layer.close(index);
    			return false;// 取消
    		}
    	);
    }
    
    //全选
    function selectAll(name,obj){
    	$('input[name*='+name+']').prop('checked', $(obj).checked);
    }   
    
    function get_help(obj){
        layer.open({
            type: 2,
            title: '帮助手册',
            shadeClose: true,
            shade: 0.3,
            area: ['90%', '90%'],
            content: $(obj).attr('data-url'), 
        });
    }
    
    function delAll(obj,name){
    	var a = [];
    	$('input[name*='+name+']').each(function(i,o){
    		if($(o).is(':checked')){
    			a.push($(o).val());
    		}
    	})
    	if(a.length == 0){
    		layer.alert('请选择删除项', {icon: 2});
    		return;
    	}
    	layer.confirm('确认删除？', {btn: ['确定','取消'] }, function(){
    			$.ajax({
    				type : 'get',
    				url : $(obj).attr('data-url'),
    				data : {act:'del',del_id:a},
    				dataType : 'json',
    				success : function(data){
    					if(data == 1){
    						layer.msg('操作成功', {icon: 1});
    						$('input[name*='+name+']').each(function(i,o){
    							if($(o).is(':checked')){
    								$(o).parent().parent().remove();
    							}
    						})
    					}else{
    						layer.msg(data, {icon: 2,time: 2000});
    					}
    					layer.closeAll();
    				}
    			})
    		}, function(index){
    			layer.close(index);
    			return false;// 取消
    		}
    	);	
    }
    laydate.render({
        elem: '#start_time'
        ,min: 0
        ,max: 2000
    });
    laydate.render({
        elem: '#end_time'
        ,min: 0
        ,max: 2000
    });
    </script>

  </head>
  <body style="background-color:#ecf0f5;">
 

<div class="wrapper">
    <div class="breadcrumbs" id="breadcrumbs">
	<ol class="breadcrumb">
	<?php if(is_array($navigate_admin)): foreach($navigate_admin as $k=>$v): if($k == '后台首页'): ?><li><a href="<?php echo ($v); ?>"><i class="fa fa-home"></i>&nbsp;&nbsp;<?php echo ($k); ?></a></li>
	    <?php else: ?>    
	        <li><a href="<?php echo ($v); ?>"><?php echo ($k); ?></a></li><?php endif; endforeach; endif; ?>          
	</ol>
</div>

    <section class="content">
        <!-- Main content -->
        <div class="container-fluid">
            <div class="pull-right">
                <a href="javascript:history.go(-1)" data-toggle="tooltip" title="" class="btn btn-default" data-original-title="返回"><i class="fa fa-reply"></i></a>
           		<!--<a href="javascript:;" class="btn btn-default" data-url="http://www.shop.yiqidongfang.com/Doc/Index/article/id/1010/developer/user.html" onclick="get_help(this)"><i class="fa fa-question-circle"></i> 帮助</a>-->
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-list"></i> 新增地区</h3>
                </div>
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab_tongyong" data-toggle="tab">新增地区</a></li>
                    </ul>
                    <!--表单数据-->
                    <form method="post" id="addEditBrandForm" action="<?php echo U('Admin/Manage/area_new_add');?>" onsubmit="return check_all();">

                        <!--通用信息-->
                    <div class="tab-content">                 	  
                        <div class="tab-pane active" id="tab_tongyong">
                           
                            <table class="table table-bordered">
                                <tbody>
                                <tr>
                                    <td>请选择新开通的城市:</td>
                                    <td>
                                        <label for="province"></label>
                                        <div class="row">

                                            <div class="col-lg-3 " style="width: 30%;">

                                                <select class="form-control " name="province" id="province" onChange="get_city(this,2)" >
                                                    <option  value="0">请选择</option>
                                                    <?php if(is_array($province)): $i = 0; $__LIST__ = $province;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$p): $mod = ($i % 2 );++$i;?><option   value="<?php echo ($p["id"]); ?>"><?php echo ($p["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 " style="width: 30%;" >
                                                <select class="form-control" name="city" id="city" >
                                                    <option  value="0">请选择</option>

                                                </select>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>社保补缴办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="sb_bujiao" class="form-control" style="width:150px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/月&nbsp;&nbsp;

                                    </td>
                                </tr>
                                <tr>
                                    <td>个人单独【社保/公积金】 代缴办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian][month]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/月&nbsp;&nbsp;
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian][season]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/> &nbsp;元/季&nbsp;&nbsp;
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian][half_year]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/半年&nbsp;&nbsp;
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian][year]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/年&nbsp;&nbsp;

                                    </td>
                                </tr>
                                <tr>
                                    <td>个人【五险一金】 代缴办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian_and_gjj][month]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/月&nbsp;&nbsp;
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian_and_gjj][season]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/> &nbsp;元/季&nbsp;&nbsp;
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian_and_gjj][half_year]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/半年&nbsp;&nbsp;
                                        <input type="text" value="<?php echo ($info["sb_bujiao"]); ?>" name="own[wuxian_and_gjj][year]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/年&nbsp;&nbsp;

                                    </td>
                                </tr>
                                <tr>
                                    <td>企业【挂靠】单独【社保/公积金】办理服务费:</td>
                                    <td>
                                        【0-10人】<input type="text" value="" name="company[guakao][wuxian][ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/月&nbsp;&nbsp;
                                        【大于10人】<input type="text" value="" name="company[guakao][wuxian][gt_ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/> &nbsp;元/人/月&nbsp;&nbsp;

                                    </td>
                                </tr>
                                <tr>
                                    <td>企业【挂靠】【五险一金】 代缴办理服务费:</td>
                                    <td>
                                        【0-10人】<input type="text" value="" name="company[guakao][wuxian_and_gjj][ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/月&nbsp;&nbsp;
                                        【大于10人】<input type="text" value="" name="company[guakao][wuxian_and_gjj][gt_ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/> &nbsp;元/人/月&nbsp;&nbsp;
                                    </td>
                                </tr>
                                <tr>
                                    <td>企业【代理】单独【社保/公积金】办理服务费:</td>
                                    <td>
                                        【0-10人】<input type="text" value="" name="company[daili][wuxian][ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/年&nbsp;&nbsp;
                                        【大于10人】<input type="text" value="" name="company[daili][wuxian][gt_ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/> &nbsp;元/人/月&nbsp;&nbsp;
                                    </td>
                                </tr>

                                <tr>
                                    <td>企业【代理】【五险一金】 代缴办理服务费:</td>
                                    <td>
                                        【0-10人】<input type="text" value="" name="company[daili][wuxian_and_gjj][ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;元/年&nbsp;&nbsp;
                                        【大于10人】<input type="text" value="" name="company[daili][wuxian_and_gjj][gt_ten]" class="form-control" style="width:80px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/> &nbsp;元/人/月&nbsp;&nbsp;
                                    </td>
                                </tr>
                                <tr>
                                    <td>公积金补缴办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["gjj_bujiao"]); ?>" name="gjj_bujiao" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}" />&nbsp;&nbsp;元
                                    </td>
                                </tr>

                                <tr>
                                    <td>社保转移办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["sb_zhuanyi"]); ?>" name="sb_zhuanyi" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>公积金转移办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["gjj_zhuanyi"]); ?>" name="gjj_zhuanyi" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>住房公积金提取办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["gjj_tiqu"]); ?>" name="gjj_tiqu" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>医疗手工报销办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["yl_sgz"]); ?>" name="yl_sgz" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>生育待遇申领办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["sy_shenqing"]); ?>" name="sy_shenqing" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>异地就医备案办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["yd_bajy"]); ?>" name="yd_bajy" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>社保信息修改办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["sb_editinfo"]); ?>" name="sb_editinfo" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>个人所得税申报办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["own_money"]); ?>" name="own_money" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>退休养老办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["tx_yanglao"]); ?>" name="tx_yanglao" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>孩子上学材料办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["school_info"]); ?>" name="school_info" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){ layer.msg('只能是数字或者小数', {icon: 2,time: 3000});this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>
                                <tr>
                                    <td>天津人才引进办理服务费:</td>
                                    <td>
                                        <input type="text" value="<?php echo ($info["rc_yingjin"]); ?>" name="rc_yingjin" class="form-control" style="width:250px;"  onkeyup= "if(!/^[0-9]+(.[0-9]{0,2})?$/.test(this.value)){  layer.msg('只能是数字或者小数', {icon: 2,time: 3000}) ;this.value='';}"/>&nbsp;&nbsp;元
                                    </td>
                                </tr>

                                </tbody>                                
                                </table>
                        </div>                           
                    </div>              
                    <div class="pull-right">
                        <!--<input type="hidden" name="id" value="<?php echo ($id); ?>">-->
                        <button class="btn btn-primary" data-toggle="tooltip" type="submit" data-original-title="保存">保存</button>
                    </div>
			    </form><!--表单数据-->
                </div>
            </div>
        </div>    <!-- /.content -->
    </section>
</div>
<script>

// 判断输入框是否为空
function check_all(){
	var province = $("#province").val();
	var city = $("#city").val();

    if(province ==0 || city==0)
	{
        layer.msg('请选择开通地区', {icon: 2,time: 3000});
		return false;
	}

	return true;
}


</script>
</body>
</html>