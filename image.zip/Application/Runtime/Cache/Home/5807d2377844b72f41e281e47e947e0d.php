<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title>服务办理</title>
 <meta charset="utf-8">
 <!--<meta http-equiv="X-UA-Compatible" content="IE=edge">-->
 <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
 <!--<link rel="icon" href="/Public/images/b.ico" type="img/x-ico" />-->
 <!--<script src="/Template/pc/default/Static/js/jquery-1.11.0.min.js"></script>-->
	<!--<link href="./style.css" rel="stylesheet" type="text/css">-->
 <link href="/Template/pc/default/Static/css/style_mobile.css" rel="stylesheet">
 <!--<link href="/Template/pc/default/Static/css/bootstrap.min.css" rel="stylesheet">-->
 <!--<script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>-->
 <!--<script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>-->
 <![endif]-->
 <link href="/Public/bootstrap/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
</head>
<body style="padding-top: 0px;">

<div class="banner" style="margin-bottom: 5px;">
 <img src="/Template/pc/default/Static/images/new/562897a85ba37.png" style="width:100%;height: 20%;" >
</div>
<div style="margin-left: 1%;">
<ul class="long">
<li>
<a href="<?php echo U('Home/Checklogin/shebao_dj');?>"  class="m2sver_aBox">
 <div class="m2sverIcon">
  <!--<img src="./images/m2sb_icon1.png" width="110" height="110">-->
  <i class="fa  fa-renren fa-3x"></i>
 </div>
 <div class="m2sverNm">社保代缴</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">社保代缴</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
<li>
<a href="<?php echo U('Home/Checklogin/shebao_bujiao');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-yelp fa-3x"></i>
 </div>
 <div class="m2sverNm">社保补缴</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">社保补缴</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li><li>
<a href="<?php echo U('Home/Checklogin/shebao_bujiao');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-gittip fa-3x"></i>
 </div>
 <div class="m2sverNm">公积金代缴</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">公积金代缴</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/shebao_bujiao');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-star-half-full fa-3x"></i>
 </div>
 <div class="m2sverNm">公积金代缴</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">公积金代缴</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/gongjijin_bujiao');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-suitcase fa-3x"></i>
 </div>
 <div class="m2sverNm">公积金补缴</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">公积金补缴</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>

 <li>
<a href="<?php echo U('Home/Checklogin/shebao_zhuanyi');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-minus-square-o fa-3x"></i>
 </div>
 <div class="m2sverNm">社保转移</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">社保转移</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/gjj_zhuanyi');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-check-square-o fa-3x"></i>
 </div>
 <div class="m2sverNm">公积金转移</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">公积金转移</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/gjj_tiqu');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-rupee fa-3x"></i>
 </div>
 <div class="m2sverNm">住房公积金提取</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">住房公积金提取</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/yl_sgz');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-file-sound-o fa-3x"></i>
 </div>
 <div class="m2sverNm">医疗手工报销</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">医疗手工报销</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/sy_shenqing');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-mars-double fa-3x"></i>
 </div>
 <div class="m2sverNm">生育待遇申领</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">生育待遇申领</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/yd_bajy');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-plus-square fa-3x"></i>
 </div>
 <div class="m2sverNm">异地就医备案</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">异地就医备案</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/sb_editinfo');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-align-center fa-3x"></i>
 </div>
 <div class="m2sverNm">社保信息修改</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">社保信息修改</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>

 <li>
<a href="<?php echo U('Home/Checklogin/own_money');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-cny fa-3x"></i>
 </div>
 <div class="m2sverNm">个人所得税申报</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">个人所得税申报</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/tx_yanglao');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-user-secret fa-3x"></i>
 </div>
 <div class="m2sverNm">退休养老办理</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">退休养老办理</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/school_info');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-file-excel-o fa-3x"></i>
 </div>
 <div class="m2sverNm">孩子上学材料</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">孩子上学材料</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>
 <li>
<a href="<?php echo U('Home/Checklogin/rc_yingjin');?>" target="_blank" class="m2sver_aBox">
 <div class="m2sverIcon">
  <i class="fa  fa-user fa-3x"></i>
 </div>
 <div class="m2sverNm">天津人才引进</div>
 <div class="m2svrLayer">
 <div class="m2svr_s1">天津人才引进</div>
 <span class="m2svr_m">办理</span>
 </div>
</a>
</li>

</ul>
</div>
</body>
</html>>