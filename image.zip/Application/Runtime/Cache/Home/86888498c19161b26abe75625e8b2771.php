<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>社保补缴订单</title>

    <!-- Bootstrap -->
    <link href="/Template/pc/default/Static/css/mobile_center_css/bootstrap.min.css" rel="stylesheet">
    <link href="/Template/pc/default/Static/css/mobile_center_css/zhangmu.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <!--<script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>-->
    <!--<script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>-->
    <!--[endif]-->
    <script src="/Template/pc/default/Static/js/mobile_js/jquery.min.js"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="/Template/pc/default/Static/js/mobile_center_js/jquery2.14.min.js"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="/Template/pc/default/Static/js/mobile_center_js/jquery2.14.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/Template/pc/default/Static/js/mobile_center_js/bootstrap.min.js"></script>
    <script src="/Template/pc/default/Static/js/mobile_center_js/Other.js"></script>
    <link rel="stylesheet" href="/Template/pc/default/Static/font_awesome/css/font-awesome.min.css">
    <script src="/Public/js/layer/layer.js"></script>
</head>
<body>

<!--导航栏-->
<nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color: #ffffff;">
    <p class="nav_li nav_li1">
        <a href="<?php echo U('MobileOrder/my_index');?>">
            <i class="fa fa-angle-double-left fa-lg"></i> 返回</a>
    </p>
    <p class="nav_li nav_title  nav_li2">社保补缴订单详情</p>
    <!--<p class="nav_li nav_li3"><a href="<?php echo U('Home/MobileOrder/company_staff_add');?>">添加员工</a></p>-->
</nav>

<section class="topheight">
    <div style="margin: 60px auto;background-color: #ffffff;">
        <table class="table table-striped table-bordered">

            <?php if(is_array($mess)): $k = 0; $__LIST__ = $mess;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$info): $mod = ($k % 2 );++$k;?><tr>
                    <th colspan="9"><?php echo ($service_name); ?></th>
                </tr>
                <tr>
                    <th class="td_h1">办理人</th>
                    <th class="td_h2" colspan="2"><?php echo ($info["username"]); ?></th>
                    <th class="td_h3">补缴日期</th>
                    <th class="td_h3" colspan="2"><?php echo ($info["start_time"]); ?>|<?php echo ($info["end_time"]); ?></th>
                    <th class="td_h3" >身份证号</th>
                    <th class="td_h3" colspan="2"><?php echo ($info["idcard"]); ?></th>

                </tr>
                <tr>
                    <th class="td_h1">办理城市</th>
                    <th class="td_h2" colspan="2"><?php echo ($info["top_name"]); ?>—<?php echo ($info["toc_name"]); ?></th>
                    <th class="td_h3" >联系电话</th>
                    <th class="td_h3" colspan="2">      <?php echo ($info["mobile"]); ?></th>
                    <th class="td_h3">性别</th>
                    <th class="td_h3" colspan="2"> <?php switch($info["sex"]): case "1": ?>男<?php break;?>
                        <?php case "2": ?>女<?php break;?>
                        <?php default: ?>保密<?php endswitch;?> </th>
                </tr>
                <tr>
                    <th class="td_h1">状态</th>
                    <th class="td_h2" colspan="2">                                                                  <?php switch($info["status"]): case "0": ?>未审核<?php break;?>
                        <?php case "1": ?>已审核<?php break;?>
                        <?php case "2": ?>审核通过<?php break;?>
                        <?php case "3": ?>办理中<?php break;?>
                        <?php case "4": ?>已完成<?php break;?>
                        <?php default: ?>无<?php endswitch;?> </th>
                    <th class="td_h3">办理证明</th>
                    <th class="td_h3" colspan="2">
                        <?php if(empty($info['certify']) == true): ?>暂未上传 <?php else: ?><a href="<?php echo ($info["certify"]); ?>">点击下载证明</a><?php endif; ?>
                    </th>
                    <th class="td_h3" >合同</th>
                    <th class="td_h3" colspan="2">
                        <?php if(empty($info['ht']) == true): ?>暂未上传
                            <?php else: ?>
                            <a href="<?php echo ($info["ht"]); ?>">点击下载合同</a><?php endif; ?>
                    </th>

                </tr>
                <tr>
                    <th class="td_h1">序号</th>
                    <th class="td_h2">下单日期</th>
                    <th class="td_h3" rowspan="2">养老</th>
                    <th class="td_h3" rowspan="2">失业</th>
                    <th class="td_h3" rowspan="2">工伤</th>
                    <th class="td_h3" rowspan="2">医疗</th>
                    <th class="td_h3" rowspan="2">生育</th>
                    <th class="td_h3" rowspan="2">公积金</th>
                    <th class="td_h3" rowspan="2">金额</th>
                </tr>
                <tr>
                    <td class="td_h1"><?php echo ($k); ?></td>
                    <td class="td_h2"><?php echo (date('Y-m-d',$info["add_time"])); ?></td>
                </tr>
                <tr>
                    <td class="td_h1">基数(元)</td>
                    <td class="td_h3">-</td>
                    <td class="td_h2"><?php echo ($info["sb_base"]); ?></td>
                    <td class="td_h3"><?php echo ($info["sb_base"]); ?></td>
                    <td class="td_h3"><?php echo ($info["sb_base"]); ?></td>
                    <td class="td_h2"><?php echo ($info["sb_base"]); ?></td>
                    <td class="td_h3"><?php echo ($info["sb_base"]); ?></td>
                    <td class="td_h3"><?php echo ($info["gjj_base"]); ?></td>
                    <td class="td_h3">-</td>
                </tr>
                <tr>
                    <td class="td_h1">企业(元)</td>
                    <td class="td_h3">-</td>
                    <td class="td_h2"><?php echo ($info["xian_one_company"]); ?></td>
                    <td class="td_h3"><?php echo ($info["xian_two_company"]); ?></td>
                    <td class="td_h3"><?php echo ($info["xian_three_company"]); ?></td>
                    <td class="td_h2"><?php echo ($info["xian_four_company"]); ?></td>
                    <td class="td_h3"><?php echo ($info["xian_five_company"]); ?></td>
                    <td class="td_h3"><?php echo ($info["gjj_company"]); ?></td>
                    <td class="td_h3"><?php echo ($info["company_total"]); ?></td>
                </tr>
                <tr>
                    <td class="td_h1">个人(元)</td>
                    <td class="td_h3">-</td>
                    <td class="td_h2"><?php echo ($info["xian_one_own"]); ?></td>
                    <td class="td_h3"><?php echo ($info["xian_two_own"]); ?></td>
                    <td class="td_h3"><?php echo ($info["xian_three_own"]); ?></td>
                    <td class="td_h2"><?php echo ($info["xian_four_own"]); ?></td>
                    <td class="td_h3"><?php echo ($info["xian_five_own"]); ?></td>
                    <td class="td_h3"><?php echo ($info["gjj_own"]); ?></td>
                    <td class="td_h3"><?php echo ($info["own_total"]); ?></td>
                </tr>
                <tr>
                    <td class="td_h1 td_h5" colspan="8">服务费</td>

                    <td class="td_h3"><?php echo ($info["service_fee"]); ?></td>
                </tr>
                <tr>
                    <td class="td_h1 td_h5" colspan="8">滞纳金</td>

                    <td class="td_h3"><?php echo ($info["zhina"]); ?></td>
                </tr>

                <tr>
                    <td class="td_h1 td_h5" colspan="8">个人总计</td>
                    <td class="td_h3"><?php echo ($info["money"]); ?></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
        <?php if($pay_data["is_pay"] == 0): ?><a href="<?php echo U('Home/MobileOrder/get_parameter',array('table'=>sb_bujiao,'order_sn'=>$order_sn));?>" style="width: 50%;margin:10px auto;" class="btn btn-success  btn-block">去支付</a><?php endif; ?>
    </div>
</section>

<script>
    function del(obj,user_id){
        $.ajax({
            url:'<?php echo U("Home/Order/ajax_del");?>',
            type:'post',
            data:{'user_id':user_id},
            dataType:'json',
            success:function(e){
                if(e.code==1){
                    $(obj).parent().parent().remove();
                }else{
                    layer.alert(e.mess, {icon: 5});
                }
                // window.location.reload();
            }
        })
    }
    layer.alert("由于数据量较大,请使用手机横屏模式查看", {icon: 6});
</script>
</body>
</html>