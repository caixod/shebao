<?php
return array(
   //'API_SECRET_KEY'=>'www.shop.yiqidongfang.com', // app 调用的签名秘钥
   //'API_SECRET_KEY'=>'yiqidongfang.com', // app 调用的签名秘钥
);